import time
from selenium.webdriver.common.by import By
import BaseClasses.Login as element
import Config.config as config

def test_valid_login(open_browser):
    driver = open_browser
    print(driver.title)
    driver.implicitly_wait(5)
    # click on sign in button in the home page
    driver.find_element(By.XPATH, element.Sign_In).click()

    # Enter the registered email
    driver.find_element(By.XPATH, element.email_field).send_keys(config.email)

    # enter the valid  password
    driver.find_element(By.XPATH, element.password_field).send_keys(config.password)

    # click on Signin
    driver.find_element(By.XPATH, element.submit_btn).click()

    time.sleep(10)

    #Assertion

   

    result = driver.find_element(By.XPATH, "//span[contains(text(),'My account')]").text

    try:

        #Assertion

        # After valid sign in this text should appear in the page

        assert result == 'My account'

    except Exception as e:

        print(repr(e))

        print("login is not successfull")

