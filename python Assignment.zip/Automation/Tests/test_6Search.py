from selenium.webdriver.support.select import Select
import time
from selenium.webdriver.common.by import By
import BaseClasses.Login as login
import Config.config as config
import BaseClasses.Search as search

def test_search(open_browser):
    driver = open_browser
    print(driver.title)
    driver.implicitly_wait(5)


    #searching for "printed dresses"
    driver.find_element(By.XPATH, search.search_box).send_keys(config.search)


    #click on search
    driver.find_element(By.XPATH,search.search_btn).click()
    time.sleep(5)
    #assertion
    result = driver.find_element(By.XPATH, "/html/body/div[1]/div[2]/div/div[3]/div[2]/h1/span[1]").text
    assert result == config.searchResult 

    #assertion

    #finding the result 'printed dress' field after the search

    result = driver.find_element(By.XPATH, "/html/body/div[1]/div[2]/div/div[3]/div[2]/h1/span[1]").text

    try:

        assert result == config.searchResult

    except Exception as e:

        print(repr(e))

        print("search is not working properly")