from selenium.webdriver.support.select import Select
import time
from selenium.webdriver.common.by import By
import BaseClasses.Login as login
import Config.config as config
import BaseClasses.Address as address
import BaseClasses.CreateAccount as element
def test_add_Address(open_browser):
    driver = open_browser
    print(driver.title)
    driver.implicitly_wait(5)
    # click on sign in button in the home page
    driver.find_element(By.XPATH, login.Sign_In).click()

    # Enter the registered email
    driver.find_element(By.XPATH, login.email_field).send_keys(config.email)

    # enter the valid  password
    driver.find_element(By.XPATH, login.password_field).send_keys(config.password)

    # click on Signin
    driver.find_element(By.XPATH, login.submit_btn).click()
    
    #myaddresses
    driver.find_element(By.XPATH,address.my_addres).click()
    #newAddress
    driver.find_element(By.XPATH,address.new_addres).click()
        
    driver.find_element(By.XPATH, element.Address1).send_keys(config.address_line1)
    # addressline 2
    driver.find_element(By.XPATH, element.Address2).send_keys(config.address_line2)
    #entering city
    driver.find_element(By.XPATH, element.City).send_keys(config.city_name)
    #state
    state = Select(driver.find_element(By.XPATH, element.State))
    state.select_by_value("14")
    #postal code
    driver.find_element(By.XPATH, element.Postcode).send_keys(config.pin_code)
    #country
    sel = Select(driver.find_element(By.XPATH, element.Country))
    sel.select_by_value("21")
    #homephone
    driver.find_element(By.XPATH, element.Phone).send_keys(config.home_phone)
    # mobilenumer
    driver.find_element(By.XPATH, element.Mobile_No).send_keys(config.mobile_number)

    #adding alias
    driver.find_element(By.XPATH, address.add_alias).send_keys(config.add_alias)

    #save button
    driver.find_element(By.XPATH, address.save_btn).click()
    

    time.sleep(5)

    # assertion

    # MY ADDRESS field is the new address added, so this element should be there in the page

    result = driver.find_element(By.XPATH, "//h3[contains(text(),'My address1')]").text

    try:

        assert result == 'MY ADDRESS1'

    except Exception as e:

        print(repr(e))

        print("addAddress is not done properly")



