from cmath import log
from selenium.webdriver.support.select import Select
import time
from selenium.webdriver.common.by import By
import BaseClasses.Login as login
import Config.config as config
import BaseClasses.Address as address


def test_delete_address(open_browser):
    driver = open_browser
    print(driver.title)
    driver.implicitly_wait(5)
    # signin
    driver.find_element(By.XPATH, login.Sign_In).click()

    # Enter the registered email
    driver.find_element(By.XPATH, login.email_field).send_keys(config.email)

    # enter the valid  password
    driver.find_element(By.XPATH, login.password_field).send_keys(config.password)

    # click on Signin
    driver.find_element(By.XPATH, login.submit_btn).click()

    #click on Address field
    driver.find_element(By.XPATH, address.my_addres).click()
    time.sleep(5)

    #click on delete address
    driver.find_element(By.XPATH, address.delete_addres).click()

    time.sleep(5)

    # click on pop up
    alert = driver.switch_to.alert
    alert.accept()
    time.sleep(5)

    #assertion

    #we should get an exeption becuase MyAdress1 field will not be there after deleting address

    flag = 0

    try:

        result = driver.find_element(By.XPATH("//body/div[@id='page']/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/ul[1]"))

    except Exception as e:

        print(repr(e))

        flag =1

        print("there is no 2nd Address field")

    assert flag == 1




