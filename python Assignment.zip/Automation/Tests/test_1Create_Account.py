import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
import BaseClasses.CreateAccount as element
import Config.config as config

def test_CreateAccount(open_browser):
    driver = open_browser
    driver.implicitly_wait(5)
    driver.find_element(By.XPATH, element.SignIn).click()
    driver.find_element(By.XPATH, element.Email_Signup).send_keys(config.email)
    driver.find_element(By.XPATH, element.Submit_Create).click()
    # Personal Info - New Account
    driver.find_element(By.XPATH,element.Create_Acc).click()
    driver.find_element(By.XPATH, element.First_Name).send_keys(config.first_name)
    driver.find_element(By.XPATH, element.Last_Name).send_keys(config.last_name)
    driver.find_element(By.XPATH, element.Password).send_keys(config.password)
    
    

    day = Select(driver.find_element(By.XPATH, element.Dob_Day))
    day.select_by_index(6)
    month = Select(driver.find_element(By.XPATH,element.Dob_Month))
    month.select_by_index(5)
    year = Select(driver.find_element(By.XPATH, element.Dob_Year))
    year.select_by_index(14)
    
    
    driver.find_element(By.XPATH, element.First_Name).send_keys(config.first_name)
    driver.find_element(By.XPATH, element.Last_Name).send_keys(config.last_name)
    #company name
    driver.find_element(By.XPATH, element.Company_Name).send_keys(config.company_name)
    #addressline 1
    driver.find_element(By.XPATH, element.Address1).send_keys(config.address_line1)
    # addressline 2
    driver.find_element(By.XPATH, element.Address2).send_keys(config.address_line2)
    #entering city
    driver.find_element(By.XPATH, element.City).send_keys(config.city_name)
    #state
    state = Select(driver.find_element(By.XPATH, element.State))
    state.select_by_value("14")
    #postal code
    driver.find_element(By.XPATH, element.Postcode).send_keys(config.pin_code)
    #country
    sel = Select(driver.find_element(By.XPATH, element.Country))
    sel.select_by_value("21")
    #homephone
    driver.find_element(By.XPATH, element.Phone).send_keys(config.home_phone)
    #register button
    driver.find_element(By.XPATH,element.Reg_Button).click()

    time.sleep(10)
    # driver.find_element(By.XPATH, "//button[@id='submitAccount']").click()
    time.sleep(3)

    #Assertion

    #after registration 'My Account' text will apper in the page

    result = driver.find_element(By.XPATH, "//span[contains(text(),'My account')]").text



    try:

        #After registration this text should appear in the page

        assert result == config.registerResult

    except Exception as e:

        print(repr(e))

        print("Registration is failed")


    
