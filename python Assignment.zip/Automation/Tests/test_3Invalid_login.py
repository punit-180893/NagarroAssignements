import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
import BaseClasses.Login as element
import Config.config as config

def test_invalid_login(open_browser):
    driver = open_browser
    print(driver.title)
    driver.implicitly_wait(5)
    # click on sign in button in the home page
    driver.find_element(By.XPATH,element.Sign_In).click()

    # Enter the registered email
    driver.find_element(By.XPATH, element.email_field).send_keys(config.email)

    # enter the invalid  password
    driver.find_element(By.XPATH, element.password_field).send_keys(config.invalid_password)

    # click on Signin
    driver.find_element(By.XPATH, element.submit_btn).click()

    time.sleep(10)

    #Assertion

    #finding the 'Authentication failed'  field, after invalif signin this should be there in the page

    result = driver.find_element(By.XPATH, "//li[contains(text(),'Authentication failed.')]").text

    try:

        #After invalid sign in this text should appear in the page

        assert result == 'Authentication failed.'

    except Exception as e:

        print(repr(e))

        print("invalid login testcse is failed")