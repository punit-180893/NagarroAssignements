Sign_In = "//a[contains(text(),'Sign in')]"
email_field = "//input[@id='email']"
password_field = "//input[@id='passwd']"
submit_btn = "//button[@id='SubmitLogin']"
