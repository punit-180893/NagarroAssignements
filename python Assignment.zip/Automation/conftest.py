from _pytest.fixtures import fixture
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from Config import config


@fixture(scope="module")
def open_browser():
    global driver
    if config.mode.lower() == "non-headless":
        if config.browser.lower() == "chrome":
            driver = webdriver.Chrome(config.chrome_driver)
            # return driver
        elif config.browser.lower() == "firefox":
            driver = webdriver.Firefox(config.firefox_driver)
            # return driver
        else:
            print("Browser name is incorrect")
    elif config.mode.lower() == "headless":
        if config.browser.lower() == "chrome":
            options = Options()
            options.headless = True
            driver = webdriver.Chrome(config.chrome_driver, options=options)
            # return driver
        elif config.browser.lower() == "firefox":
            options = Options()
            options.headless = True
            driver = webdriver.Firefox(config.firefox_driver, options=options)
            # return driver
        else:
            print("Browser name is invalid")
    driver.maximize_window()
    driver.delete_all_cookies()
    driver.get(config.baseUrl)
    yield driver
    driver.close()