package base;

import Utilities.ExtentManager;
import Utilities.ReadingPropertiesFile;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;

public class BasePage {

    protected static ReadingPropertiesFile readingPropertiesFile = new ReadingPropertiesFile();
    protected static RequestSpecification httpRequest;
    public static ExtentReports extent;
    public static ExtentTest test;
    public static Logger logger = null;


    @BeforeSuite
    public static void init() throws MalformedURLException{
       extent = ExtentManager.getInstance("Report//ExtentReport.html");
    }


    @BeforeMethod
    public void startTest(Method method) {
        String log4jPath = System.getProperty("user.dir")+ "\\log4j.properties";
        PropertyConfigurator.configure(log4jPath);
        httpRequest = RestAssured.given();
        test = extent.startTest(method.getName());
    }


    @AfterMethod
    public void afterMethod(ITestResult result) throws IOException {

        System.out.println(result.getMethod().getMethodName());

            if(result.getStatus()==ITestResult.SUCCESS)
                test.log(LogStatus.PASS, "Test case passed");
            else if(result.getStatus()==ITestResult.FAILURE) {
                test.log(LogStatus.FAIL, result.getThrowable());
            }

            else if(result.getStatus()==ITestResult.SKIP)
                test.log(LogStatus.SKIP, result.getThrowable());

            extent.flush();

        }

    }

