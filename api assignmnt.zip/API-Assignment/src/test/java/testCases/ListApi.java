package testCases;

import Utilities.ReadingPropertiesFile;
import Utilities.Resources;
import Utilities.restClientWrapper;
import base.BasePage;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ListApi extends BasePage {
    String body ="{\"name\":\"PunitSharmaList\"}";
    static String ListID;

    private static Utilities.restClientWrapper restClientWrapper;
    private static String baseUrl;
    private static String resource = "/1/actions/3";

    @BeforeClass
    public void setUpTest() {
        baseUrl = ReadingPropertiesFile.getProperty("baseurl");

    }

    @BeforeMethod
    public void SetupRequest() {
        System.out.println(baseUrl + httpRequest);
        restClientWrapper = new restClientWrapper(baseUrl, httpRequest);
        logger = Logger.getLogger(BoardMainTest.class.getName());

    }

    @Test(priority = 0)
    public void TrelloPost() throws Exception {
        Response serverResponse = restClientWrapper.post(Resources.postendPointList, body);
        serverResponse.prettyPeek();
        String endpoint = serverResponse.asString();
        JsonPath js = new JsonPath(endpoint);
        ListID = js.get("id") ;
        test.log(LogStatus.INFO,serverResponse.asString());
    }

    @Test(priority = 1)
    public void TrelloGet() throws Exception {
        Response serverResponse = restClientWrapper.get(Resources.getendPointList+ListID);
        serverResponse.prettyPeek();

        test.log(LogStatus.INFO, serverResponse.asString());
    }
    @Test(priority = 2)
    public void TrelloPut() throws Exception {
        Response serverResponse = restClientWrapper.put(Resources.putendPointList+ListID, body);
        serverResponse.prettyPeek();
    }

}
