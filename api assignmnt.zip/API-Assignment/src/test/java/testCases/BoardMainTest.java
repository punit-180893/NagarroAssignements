package testCases;

import Utilities.Resources;
import Utilities.restClientWrapper;
import base.BasePage;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class BoardMainTest extends BasePage {
    String body ="{\"name\":\"PunitSharmaBoard\"}";
    static String boardID;

    private static Utilities.restClientWrapper restClientWrapper;
    private static String baseUrl;
    private static String resource = "/1/actions/3";

    @BeforeClass
    public void setUpTest() {
        baseUrl = readingPropertiesFile.getProperty("baseurl");

    }

    @BeforeMethod
    public void SetupRequest() {
        System.out.println(baseUrl + httpRequest);
        restClientWrapper = new restClientWrapper(baseUrl, httpRequest);
        logger =Logger.getLogger(BoardMainTest.class.getName());

    }

    @Test(priority = 0)
    public void TrelloPost() throws Exception {
        Response serverResponse = restClientWrapper.post(Resources.postendPointBoard, body);
        serverResponse.prettyPeek();
        String endpoint = serverResponse.asString();
        JsonPath js = new JsonPath(endpoint);
        boardID = js.get("id") ;
        test.log(LogStatus.INFO,serverResponse.asString());
    }

    @Test(priority = 1)
    public void TrelloGet() throws Exception {
        Response serverResponse = restClientWrapper.get(Resources.getendPointBoard+boardID);
        serverResponse.prettyPeek();

        test.log(LogStatus.INFO, serverResponse.asString());
    }
    @Test(priority = 2)
    public void TrelloPut() throws Exception {
        Response serverResponse = restClientWrapper.put(Resources.putendPointBoard+boardID, body);
        serverResponse.prettyPeek();
    }
//            @Test
//            public void TrelloDelete() throws Exception{
//                Response serverResponse = restClientWrapper.delete(Resources.deleteendpoint);
//                serverResponse.prettyPeek();
//            }

}
