package Utilities;

public class Resources {
    //defining endpoint of board
    public static String getendPointBoard = "/1/boards/";
    public static String postendPointBoard = "/1/boards/";
    public static String putendPointBoard = "/1/boards/";
    public static String deleteendpoint = "/1/boards/";
    //defining endpoint of List
    public static String getendPointList = "/1/List/";
    public static String postendPointList = "/1/List/";
    public static String putendPointList = "/1/List/";

    //defining endpoint of card

    public static String getendPointCard = "/1/Card/";
    public static String postendPointCard = "/1/Card/";
    public static String putendPointCard = "/1/Card/";


}
