package Utilities;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class restClientWrapper {

    public String response;
    public String baseUrl;
    private RequestSpecification request;
    private Response restResponse;

    public restClientWrapper(String baseUrl, RequestSpecification request) {
        this.request = request;
        this.request.baseUri(baseUrl)
                .queryParam("token",ReadingPropertiesFile.getProperty("token"))
                .queryParam("key",ReadingPropertiesFile.getProperty("key"))
                .queryParam("idBoard",ReadingPropertiesFile.getProperty("boardID"))
                .queryParam("idList",ReadingPropertiesFile.getProperty("ListID"));

    }

    public Response get(String resource) throws Exception {
        restResponse = request
                .when().get(resource);
        return restResponse;
    }

    public Response post(String resource, String bodyString) throws Exception {
        restResponse = request.header("Content-Type", "application/json; charset=UTF-8")
                .when().body(bodyString).post(resource);
        return restResponse;
    }

    public Response put(String resource, String bodyString) throws Exception {
        restResponse = request.header("Content-Type", "application/json; charset=UTF-8")
                .when().body(bodyString).put(resource);
        return restResponse;
    }

    public Response delete(String resource) throws Exception {
        restResponse = request.when().get(resource);
        return restResponse;

    }
}