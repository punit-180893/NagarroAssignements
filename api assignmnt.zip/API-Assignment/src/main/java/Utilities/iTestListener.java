package Utilities;

import org.testng.ITestResult;
import org.testng.ITestListener;

public class iTestListener implements ITestListener{

    public void onTestStart(ITestResult result){
        System.out.println("Before Test Start");
    }
    public void onTestSuccess(ITestResult result){
        System.out.println("On Test Success");
    }
    public void onTestFailure(ITestResult result){
        System.out.println("On Test failure");
    }
    public void onTestSkipped(ITestResult result){
        System.out.println("on test skipped");
    }

    }


