package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchTestPage {

    @FindBy(xpath = "//input[@id='twotabsearchtextbox']")
    WebElement SearchBox;

    @FindBy(xpath = "//input[@id='nav-search-submit-button']")
    WebElement SearchButton;

    public SearchTestPage(WebDriver driver){
        PageFactory.initElements(driver, this);
    }

    public void Search(){
        SearchBox.sendKeys("Khanjar");
    }
    public void SearchButton(){
        SearchButton.click();
    }
}
