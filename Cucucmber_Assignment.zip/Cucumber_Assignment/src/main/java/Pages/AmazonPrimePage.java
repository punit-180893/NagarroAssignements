package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AmazonPrimePage {

    @FindBy(xpath = "//a[@id='nav-hamburger-menu']")
    WebElement Menu;

    @FindBy(xpath = "//body/div[@id='hmenu-container']/div[@id='hmenu-canvas']/div[@id='hmenu-content']/ul[1]/li[11]/a[1]")
    WebElement PrimeVideo;

    @FindBy(xpath = "//a[contains(text(),'All Videos')]")
    WebElement AllVideo;

    public AmazonPrimePage(WebDriver driver){

        PageFactory.initElements(driver,this);

    }

    public void Menu() { Menu.click(); }
    public void PrimeVideo(){
        PrimeVideo.click();
    }
    public void AllVideo(){
        AllVideo.click();
    }

}
