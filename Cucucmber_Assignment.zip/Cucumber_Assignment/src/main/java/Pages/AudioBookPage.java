package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AudioBookPage {

    @FindBy(xpath = "//a[@id='nav-hamburger-menu']")
    WebElement Menu;

    @FindBy(xpath = "//body/div[@id='hmenu-container']/div[@id='hmenu-canvas']/div[@id='hmenu-content']/ul[1]/li[10]/a[1]")
    WebElement AudibleAudioBooks;

    @FindBy(xpath = "//a[contains(text(),'All Audiobooks')]")
    WebElement AllAudioBooks;

    public AudioBookPage(WebDriver driver){

        PageFactory.initElements(driver,this);

    }

    public void Menu() {
        Menu.click(); }
    public void AudibleAudioBooks(){
        AudibleAudioBooks.click();
    }
    public void AllAudioBooks(){
        AllAudioBooks.click();
    }
}
