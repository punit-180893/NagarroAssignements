package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginScenarioPage {


    @FindBy(xpath = "//a[@id='nav-link-accountList']")
    WebElement SignIn;

    @FindBy(name = "email")
    WebElement Email_tab;

    @FindBy(id = "continue")
    WebElement Continue;

    @FindBy(name = "password")
    WebElement Password_tab;

    public LoginScenarioPage(WebDriver driver) {

        PageFactory.initElements(driver, this);
    }




    public void login(String username, String password) {
        Email_tab.sendKeys(username);
        Continue.click();
        Password_tab.sendKeys(password);
    }

    public void SignIn() {
        SignIn.click();
    }
}