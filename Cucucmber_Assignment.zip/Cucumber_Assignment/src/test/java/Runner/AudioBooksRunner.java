package Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
        features = "src/test/java/Feature/AudioBooks.feature",
        glue = "StepDefinitions",
        tags = {"@AudioBooks"}
)

public class AudioBooksRunner extends AbstractTestNGCucumberTests {
}
