package Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
        features = "src/test/java/Feature/LoginScenario.feature",
        glue = "StepDefinitions",
        tags = {"@ValidLogin,@InvalidLogin"}
)


public class AmazonLoginRunner extends AbstractTestNGCucumberTests {



}
