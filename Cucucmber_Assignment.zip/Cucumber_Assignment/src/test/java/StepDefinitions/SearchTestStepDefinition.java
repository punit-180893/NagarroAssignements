package StepDefinitions;

import Pages.AmazonPrimePage;
import Pages.SearchTestPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SearchTestStepDefinition {

    public static WebDriver driver;
    SearchTestPage searchPage;
    AmazonPrimePage amazonPrimeVideoPage;

    @Given("^User Opens the Browser and Visit Amazon$")
    public void user_Opens_the_Browser_and_Visit_Amazon()  {
        System.out.println("User Opens The Browser and open Amazon.in");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\punitsharma\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.amazon.in/");
    }

    @When("^Search the Item name$")
    public void enter_the_Item_name() {
        System.out.println("Search The item name");
        searchPage = new SearchTestPage(driver);
        searchPage.Search();
    }

    @Then("^Click on search button$")
    public void click_on_search_button() {

        System.out.println("Searches the element");
        searchPage.SearchButton();
    }

    @When("^User Click On Menu Navbar$")
    public void user_Click_On_Menu_Navbar() throws Throwable {

        System.out.println("User opens Menu Navbar");
        amazonPrimeVideoPage = new AmazonPrimePage(driver);
        amazonPrimeVideoPage.Menu();
    }

    @Then("^User Clicks on AmazonPrimeVideo$")
    public void user_Clicks_on_AmazonPrimeVideo() throws Throwable {
        System.out.println("User Chooses AmazonPrimeVideo");
        amazonPrimeVideoPage.PrimeVideo();
    }

    @Then("^User goes to all videos$")
    public void user_goes_to_all_videos() throws Throwable {
        System.out.println("User Chooses All Videos and Prime Video opens up");
        amazonPrimeVideoPage.AllVideo();
    }


}
