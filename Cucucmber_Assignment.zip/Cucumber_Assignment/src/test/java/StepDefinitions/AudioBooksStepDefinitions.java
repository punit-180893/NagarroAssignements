package StepDefinitions;

import Pages.AudioBookPage;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AudioBooksStepDefinitions {
    public static WebDriver driver;
    AudioBookPage AudibleAudioBookPage;

    @Given("^User Should launch the browser and visit Amazon\\.in$")
    public void user_Should_launch_the_browser_and_visit_Amazon_in() throws Throwable {
        System.out.println("User Opens The Browser and open Amazon.in");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\punitsharma\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.amazon.in/");
    }

    @When("^user should click on All Menu$")
    public void user_should_click_on_All_Menu() throws Throwable {
        System.out.println("User opens Menu Navbar");
        AudibleAudioBookPage = new AudioBookPage(driver);
        AudibleAudioBookPage.Menu();
    }

    @Then("^user should click on Audible AudioBooks$")
    public void user_should_click_on_Audible_AudioBooks() throws Throwable {
        System.out.println("User click on Audible Audiobooks");
        AudibleAudioBookPage.AudibleAudioBooks();
    }

    @Then("^user should go to All Audible Audiobooks$")
    public void user_should_go_to_All_Audible_Audiobooks() throws Throwable {
        System.out.println("user click on All Audible Audiobooks");
        AudibleAudioBookPage.AllAudioBooks();
    }

}
