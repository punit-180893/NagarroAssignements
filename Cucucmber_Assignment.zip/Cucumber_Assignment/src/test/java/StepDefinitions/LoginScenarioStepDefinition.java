package StepDefinitions;

import Pages.LoginScenarioPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;

public class LoginScenarioStepDefinition {

    WebDriver driver;
    LoginScenarioPage amazonLoginPage;

    @Given("^user launches the browser and open amazon\\.in$")
    public void user_launches_the_browser_and_open_amazon_in() throws Throwable {


        System.setProperty("webdriver.chrome.driver", "C:\\Users\\punitsharma\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
        driver = new ChromeDriver();


        driver.manage().window().maximize();


        driver.get("https://www.amazon.in/");



    }

    @Given("^user click on the sign in button$")
    public void user_click_on_the_sign_in_button() throws Throwable {

        amazonLoginPage = new LoginScenarioPage(driver);

        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        amazonLoginPage.SignIn();

    }

    @When("^user enter valid username and password \"([^\"]*)\" \"([^\"]*)\"$")
    public void user_enter_valid_username_and_password(String username, String password) throws Throwable {

        amazonLoginPage.login(username, password);

    }

    @Then("^user is logged in$")
    public void user_is_logged_in() throws Throwable {


    }


    @When("^user enter invalid username and password \"([^\"]*)\" \"([^\"]*)\"$")
    public void user_enter_invalid_username_and_password(String username, String password) throws Throwable {
        amazonLoginPage.login(username, password);
    }

    @Then("^user is not logged in$")
    public void user_is_not_logged_in() throws Throwable {


    }

}