package fresherTraining.pages;

import org.openqa.selenium.By;

public class loginPage {
	
	public static By signclick = By.xpath("//a[@id='nav-link-accountList']");
    public static By username = By.xpath("//input[@id='ap_email']");
    public static By continuebtn = By.xpath("//input[@id='continue']");
    public static By passwd = By.xpath("//input[@id='ap_password']");

}
