package fresherTraining.pages;

import fresherTraining.pages.SearchPage;
import org.openqa.selenium.By;

public class SearchPage {
	public static By searchField = By.xpath("//input[@id='twotabsearchtextbox']");
    public static By searchSymbol = By.xpath("//input[@id='nav-search-submit-button']");
    
}

