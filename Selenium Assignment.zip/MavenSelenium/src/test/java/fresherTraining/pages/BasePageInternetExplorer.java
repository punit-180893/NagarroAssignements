package fresherTraining.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import fresherTraining.utilities.ExtentManager;
import fresherTraining.utilities.ReadingPropertiesFile;
import fresherTraining.utilities.ScreenShots;

public class BasePageInternetExplorer {
	
	public static WebDriver driver;
	public static ExtentReports extent;
	public static ExtentTest test;
	
//	static FileInputStream fis = null;
//	static Properties prop = new Properties();
//	
//	static {
//		
//		try {
//			File file = new File("./Resources/config.properties");
//			fis = new FileInputStream(file);
//		}catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
//		try {
//			prop.load(fis);
//		}catch(IOException e) {
//			e.printStackTrace();
//		}
//	}
	
	@BeforeSuite
	public void setup() throws InterruptedException {
		
//		 setting path for Internet Explorer driver
				System.setProperty("webdriver.ie.driver",
						"C:/Users/punitsharma/Downloads/IEDriverServer_Win32_4.2.0/IEDriverServer.exe");
//		System.setProperty(prop.getProperty("driver"),prop.getProperty("driverpath"));
				driver = new InternetExplorerDriver ();
//				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				//Maximize the window 
				driver.manage().window().maximize();
				
				extent = ExtentManager.getInstance("reports//ExtentReport.html");
//				Thread.sleep(5000);
	}
	
	//Initializing Url
	@BeforeMethod
	public void initializeURL() {
		driver.get(ReadingPropertiesFile.getProperty("url"));

	}
	
	@BeforeMethod
	public void beforeMethod(Method method) {
		test = extent.startTest(method.getName());
	}
	

	@AfterMethod
	public void afterMethod(ITestResult result) {
		
		if(result.getStatus()==ITestResult.SUCCESS)
			test.log(LogStatus.PASS, "Test case got passed");
		else if(result.getStatus()==ITestResult.FAILURE) {
			test.log(LogStatus.FAIL, result.getThrowable());
			ScreenShots.takeScreenShot(driver);
		}
			
		else if(result.getStatus()==ITestResult.SKIP)
			test.log(LogStatus.SKIP, result.getThrowable());
		
		extent.flush();
		
	}

		
	@AfterSuite
	public void tearDown() {
		
		//quitting the driver
				driver.quit();

	}

}
