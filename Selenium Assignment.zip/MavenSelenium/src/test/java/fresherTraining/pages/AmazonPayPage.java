/*Testing Amazon Pay clickBtn after signing in amazon website*/


package fresherTraining.pages;

import org.openqa.selenium.By;

public class AmazonPayPage {
	
	public static By clickSignIn = By.xpath("//input[@id='signInSubmit']");
	public static By clickBtn = By.xpath("//header/div[@id='navbar']/div[@id='nav-main']/div[2]/div[2]/div[1]/a[2]");

}
