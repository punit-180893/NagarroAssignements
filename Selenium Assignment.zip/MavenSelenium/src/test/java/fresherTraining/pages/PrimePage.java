package fresherTraining.pages;

import org.openqa.selenium.By;

public class PrimePage {
	
	public static By username = By.xpath("//input[@id='ap_email']");
    public static By continuebtn = By.xpath("//input[@id='continue']");
    public static By passwd = By.xpath("//input[@id='ap_password']");


}
