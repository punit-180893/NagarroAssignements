package fresherTraining.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import fresherTraining.pages.BasePage;
import fresherTraining.pages.loginPage;

public class testBuyFeature extends BasePage{
	@Test
	public void testBuyFeature() throws InterruptedException {
		driver.findElement(By.xpath("//header/div[@id='navbar']/div[@id='nav-main']/div[2]/div[2]/div[1]/a[2]")).click();
		driver.findElement(By.xpath("//body/div[@id='a-page']/div[2]/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/a[1]/img[1]")).click();
        driver.findElement(By.xpath("//input[@id='buy-now-button']")).click();
        driver.findElement(loginPage.username).sendKeys("punitsharma4014@gmail.com");
        driver.findElement(loginPage.continuebtn).click();
        driver.findElement(loginPage.passwd).sendKeys("Hiifrnss@4014");
        driver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
        
        Thread.sleep(4000);
	}
}
