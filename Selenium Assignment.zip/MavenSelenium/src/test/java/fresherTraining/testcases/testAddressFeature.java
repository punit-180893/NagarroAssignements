package fresherTraining.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import fresherTraining.pages.BasePage;

public class testAddressFeature extends BasePage{
	
	@Test
	public void testAddressFeature() throws InterruptedException{
		driver.findElement(By.xpath("//a[@id='nav-global-location-popover-link']")).click();
		driver.findElement(By.xpath("//input[@id='GLUXZipUpdateInput']")).sendKeys("123027");
		driver.findElement(By.xpath("//body/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[3]/div[2]/div[1]/div[2]/span[1]/span[1]/input[1]")).click();
		
		Thread.sleep(4000);
		
	}

}
