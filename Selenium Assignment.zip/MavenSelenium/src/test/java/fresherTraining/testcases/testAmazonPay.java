package fresherTraining.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import fresherTraining.pages.AmazonPayPage;
import fresherTraining.pages.BasePage;
import fresherTraining.pages.loginPage;

public class testAmazonPay extends BasePage{
	
	@Test
    public void AmazonPay() throws InterruptedException{
		driver.findElement(loginPage.signclick).click();
        driver.findElement(loginPage.username).sendKeys("punitsharma4014@gmail.com");
        driver.findElement(loginPage.continuebtn).click();
        driver.findElement(loginPage.passwd).sendKeys("Hiifrnss@4014");
        driver.findElement(AmazonPayPage.clickSignIn).click();
        driver.findElement(AmazonPayPage.clickBtn).click();
        Thread.sleep(4000);
    }

}
