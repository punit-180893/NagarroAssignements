package fresherTraining.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import fresherTraining.pages.BasePage;
/* When im searcching for the audible books and playing them, then they are not responding.*/
public class testAudibleAudiobooks extends BasePage{
	@Test
	public void testAudibleAudiobooks() throws InterruptedException {
		driver.findElement(By.xpath("//header/div[@id='navbar']/div[@id='nav-main']/div[1]/a[1]/span[1]")).click();
		driver.findElement(By.xpath("//div[contains(text(),'Audible Audiobooks')]")).click();
		driver.findElement(By.xpath("//a[contains(text(),'All Audiobooks')]")).click();
		driver.findElement(By.xpath("//body/div[@id='a-page']/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/a[1]/img[1]")).click();
//		driver.findElement(By.xpath("//a[contains(text(),'Hindi Audiobooks')]")).click();
//		driver.findElement(By.xpath("//body/div[@id='a-page']/div[@id='search']/div[1]/div[1]/div[1]/span[3]/div[2]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/span[1]/a[1]/div[1]/img[1]")).click();
//		driver.findElement(By.xpath("//span[contains(text(),'Chanakya Neeti')]")).click();
//		driver.findElement(By.xpath("//body/div[@id='a-page']/div[@id='dp']/div[@id='dp-container']/div[@id='hero_background']/div[@id='aud_ppd']/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/span[1]/span[1]/input[1]")).click();
		Thread.sleep(5000);
	}

}
