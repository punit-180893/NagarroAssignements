package fresherTraining.testcases;

import org.testng.annotations.Test;

import fresherTraining.pages.BasePage;
import fresherTraining.pages.SearchPage;

public class testSearch extends BasePage{
	
	@Test
	public void testSearch() throws InterruptedException {
	driver.findElement(SearchPage.searchField).sendKeys("Khanjar");
    driver.findElement(SearchPage.searchSymbol).click();
    Thread.sleep(4000);
	}
}
