package fresherTraining.testcases;

import org.testng.Assert;
import org.testng.annotations.*;

import com.relevantcodes.extentreports.LogStatus;

import fresherTraining.pages.BasePage;
import fresherTraining.pages.loginPage;

public class testLogin extends BasePage{
	

	
	@Test
	public void login() throws InterruptedException {
		//navigating to application

//		test.log(LogStatus.INFO, "Log in button clicked on Homepage");
		driver.findElement(loginPage.signclick).click();
        driver.findElement(loginPage.username).sendKeys("punitsharma4014@gmail.com");
        driver.findElement(loginPage.continuebtn).click();
        driver.findElement(loginPage.passwd).sendKeys("Hiifrnss@4014");		
//		Assert.assertEquals(driver.getTitle(), "My account - My Store");
        Thread.sleep(5000);

		}
}