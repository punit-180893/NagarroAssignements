package fresherTraining.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import fresherTraining.pages.BasePage;
import fresherTraining.pages.BasePageInternetExplorer;

public class testCarousel extends BasePageInternetExplorer{
	
	@Test
	public void testCarousel() throws InterruptedException {
	driver.findElement(By.xpath("//body/div[@id='a-page']/div[@id='pageContent']/div[@id='desktop-banner']/div[@id='gw-desktop-herotator']/div[1]/div[1]/div[1]/div[3]/a[1]")).click();
//		Thread.sleep(4000);
	}
}
