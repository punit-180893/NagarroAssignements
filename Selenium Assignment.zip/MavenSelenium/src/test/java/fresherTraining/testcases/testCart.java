package fresherTraining.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import fresherTraining.pages.BasePage;
import fresherTraining.pages.loginPage;

public class testCart extends BasePage{
	@Test
	public void testCart() {
		driver.findElement(loginPage.signclick).click();
        driver.findElement(loginPage.username).sendKeys("punitsharma4014@gmail.com");
        driver.findElement(loginPage.continuebtn).click();
        driver.findElement(loginPage.passwd).sendKeys("Hiifrnss@4014");
        driver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
        driver.findElement(By.xpath("//a[@id='nav-cart']")).click();
	}

}
