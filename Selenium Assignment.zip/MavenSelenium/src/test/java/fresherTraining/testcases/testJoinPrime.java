package fresherTraining.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import fresherTraining.pages.BasePage;
import fresherTraining.pages.PrimePage;

public class testJoinPrime extends BasePage{
	
	@Test
	public void testJoinPrime() throws InterruptedException {
		driver.findElement(By.xpath("//a[@id='nav-link-amazonprime']")).click();
		driver.findElement(By.xpath("//a[@id='a-autoid-0-announce']")).click();
		driver.findElement(PrimePage.username).sendKeys("9540020333");
        driver.findElement(PrimePage.continuebtn).click();
        driver.findElement(PrimePage.passwd).sendKeys("9540020333");
        driver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
		Thread.sleep(5000);
	}

}
