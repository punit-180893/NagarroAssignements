package fresherTraining.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import fresherTraining.pages.BasePage;

public class testCareerFeature extends BasePage{
	
	@Test
	public void testCareerFeature() {
		
		driver.findElement(By.xpath("//a[contains(text(),'Careers')]")).click();
		driver.findElement(By.xpath("//body/div[2]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/span[1]/input[1]")).sendKeys("Engineer");
		
	}
	
	

}
