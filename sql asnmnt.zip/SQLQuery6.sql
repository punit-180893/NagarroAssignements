--Answer 1
SELECT * FROM Production.Product
SELECT Name,Color FROM Production.Product
WHERE Weight=
(SELECT MAX(Weight)FROM Production.Product)


--Answer 2

SELECT * FROM Sales.SpecialOffer

SELECT Description,ISNULL(MaxQty, 0.00) AS 'MaxQty'  
FROM Sales.SpecialOffer; 

--Answer 3
SELECT * FROM Person.Person

SELECT ROW_NUMBER() OVER (ORDER BY FirstName ASC) AS RowNumber,FirstName,LastName
FROM Person.Person
WHERE FirstName like '%ss%'

--Answer 4
SELECT * FROM Production.Product

SELECT ProductID
FROM Production.Product
WHERE SafetyStockLevel 
NOT IN (SELECT MAX (SafetyStockLevel) 
FROM Production.Product);

--Answer 5
CREATE PROCEDURE sp_productDetail @Name VARCHAR(50)
AS
select ProductID,ProductNumber
from Production.Product
where Name = @Name

EXEC sp_productDetail @Name = 'Chainring Bolts'

select * from Production.Product