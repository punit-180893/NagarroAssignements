﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Write a program to accept patient count inputs from user for multiple days
// Get all records & ask an input from user for following actions-
// Maximum Patient counts
// Minimum Ptient counts
// Average patient counts
// Sum Of Patient counts

namespace CSAsnmnt
{
    class Que2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the days count :");
            int n = int.Parse(Console.ReadLine());
            int[] days = new int[n];
            int[] counts = new int[n];

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter the count of patients for day :" + i );
                counts[i] = int.Parse(Console.ReadLine());

            }

            Console.WriteLine("1. Maximum count of patients \n2. Minimum count of patients \n3. Average of patient count \n4. Sum of patients");
            int option = int.Parse(Console.ReadLine());
            int max = 0, min = 0, sum = 0, index = 0;
            double avg = 0;
            switch (option)
            {
                case 1:
                    {
                        max = counts.Max();
                        Console.WriteLine("Maximum count of patients is : " + max);
                        for (int i = 0; i < n; i++)
                        {
                            if (max == counts[i])
                            {
                                index = i;
                            }
                        }
                        Console.WriteLine("The day when maximum no. of patients admitted is : " + index);
                        break;

                    }
                case 2:
                    {
                        min = counts.Min();
                        Console.WriteLine("Minimum count of patients is : " + min);
                        for (int i = 0; i < n; i++)
                        {
                            if (min == counts[i])
                            {
                                index = i;
                            }
                        }
                        Console.WriteLine("The day when mininum no. of patients got admitted is : " + index);
                        break;
                    }
                case 3:
                    {
                        avg = counts.Average();
                        Console.WriteLine("Average patients count for days is : " + avg);
                        break;
                    }
                case 4:
                    {
                        sum = counts.Sum();
                        Console.WriteLine("Total count of patients admitted is : " + sum);
                        Console.WriteLine("For the count of days : " + n);
                        break;
                    }
            }
            Console.ReadLine();

        }
    }
}
