﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Write a program which accept principle amont from user
//Based on user input we will calculate the CI OR SI

namespace CSAsnmnt
{
    class Que3
    {
        public static string SI { get; private set; }

        static void MainAs(string[] args)
        { 
                Console.WriteLine("Simple Interest or Compound Interest? reply with CI or SI");
                string userinput = Console.ReadLine();
                if (userinput == "SI")
                {
                    Console.WriteLine("Enter Principal Amount");
                    double principal = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter Interest Rate");
                    double interest = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter total time period");
                    double time = Convert.ToDouble(Console.ReadLine());

                    double SI = (principal * interest * time) / 100;
                    Console.Write("Simple Interest is: " + SI);
                    Console.ReadKey();

                }
                if (userinput == "CI")
                {
                    double Total = 0, interestRate, years, annualCompound, Amount;
                    Console.Write("Enter the Initial Amount : ");
                    Amount = Convert.ToDouble(Console.ReadLine());
                    Console.Write("Enter the ROI : ");
                    interestRate = Convert.ToDouble(Console.ReadLine()) / 100;
                    Console.Write("Enter the Number of Years : ");
                    years = Convert.ToDouble(Console.ReadLine());
                    Console.Write("No. of times the interest will be Compounded : ");
                    annualCompound = Convert.ToDouble(Console.ReadLine());
                    for (int T = 1; T < years + 1; T++)
                    {
                        Total = Amount * Math.Pow((1 + interestRate / annualCompound),
                                                 (annualCompound * T));
                        Console.Write("Total Interest for Year {0} "
                                    + "is {1:F0}. \n", T, Total);

                    }

                    Console.ReadLine();
                }
        }
        
    }
}
