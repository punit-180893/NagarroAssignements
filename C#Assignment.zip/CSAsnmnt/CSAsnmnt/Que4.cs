﻿using System;
using System.Collections.Generic;

namespace CSAsnmnt
{
    class Que4
    {
        //Write a program to store 5 students name and their corresponding data

        struct student
        {
            public int RollNo;
            public int Age;
            public String Class;
            public double Percentage;
        };

        static void MainAs(string[] args)
        {
            //1st student data
            student student_1st;
            student_1st.RollNo = 1;
            student_1st.Age = 22;
            student_1st.Class = "Section A";
            student_1st.Percentage = 97.6;

            //2nd student data
            student student_2nd;
            student_2nd.RollNo = 2;
            student_2nd.Age = 22;
            student_2nd.Class = "Section A";
            student_2nd.Percentage = 98;

            //3rd student data
            student student_3rd;
            student_3rd.RollNo = 3;
            student_3rd.Age = 22;
            student_3rd.Class = "Section A";
            student_3rd.Percentage = 99.7;


            //4th student data
            student student_4th;
            student_4th.RollNo = 3;
            student_4th.Age = 22;
            student_4th.Class = "Section B";
            student_4th.Percentage = 48;

            //5th student data
            student student_5th;
            student_5th.RollNo = 5;
            student_5th.Age = 22;
            student_5th.Class = "Section B";
            student_5th.Percentage = 49;


            //creating a dictionary with key=>student name,  value = struct student
            var dictionary = new Dictionary<String, student>();
            dictionary.Add("Hrithik_Roshan", student_1st);
            dictionary.Add("AmirKhan", student_2nd);
            dictionary.Add("RajeshKhanna", student_3rd);
            dictionary.Add("Shahrukh", student_4th);
            dictionary.Add("Katrina_Kaif", student_5th);

            Console.WriteLine("Enter the student name: ");
            String name = Console.ReadLine();

            Console.WriteLine("Data Of each student " + name + " is :");
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine("Rollnumber : " + dictionary[name].RollNo);
            Console.WriteLine("Age is : " + dictionary[name].Age);
            Console.WriteLine("Class is : " + dictionary[name].Class);
            Console.WriteLine("percentage is " + dictionary[name].Percentage);

            Console.ReadLine();
        }
    }
}
