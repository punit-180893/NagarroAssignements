﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Write a program to develop application where it will ask user to :
// 1: Add record		2: Get all records	3: Get a record		4: Delete record

namespace CSAsnmnt
{
    class Que1
    {
        enum inputs
        {
            Add_record = 1,
            Get_all_records,
            Get_a_record,
            Delete_a_record,
        };
        struct records
        {
            public int id;
            public int[] salary;
            public double avgSalary;
        }
        class enumTest
        {
            public static void MainAs(String[] args)
            {
                int max = 0, i = 0, num = 0, sum = 0;
                int[] salary = new int[3];

                records[] emp = { new records(),
                       new records(),
                       new records() };

                Console.WriteLine("Type \"exit\" to exit the operations or enter any key to continue :");
                String s = Console.ReadLine();
                while (s != "exit")
                {

                    Console.WriteLine("Enter any number \n1: Add a record \n2: Get all records \n3: Get a record \n4: Delete a record");
                    int n = int.Parse(Console.ReadLine());
                    Console.WriteLine("-------------------------------------------");


                    switch ((inputs)n)
                    {
                        case inputs.Add_record:
                            {
                                Console.WriteLine("Enter the number of records you want to enter: ");
                                max = int.Parse(Console.ReadLine());
                                while (num < max)
                                {
                                    i = num;
                                    num++;
                                    Console.WriteLine("Enter the employee ID: ");
                                    emp[i].id = int.Parse(Console.ReadLine());


                                    emp[i].salary = new int[3];
                                    Console.WriteLine("Enter the 3 month salaries : ");
                                    for (int k = 0; k < 3; k++)
                                    {
                                        Console.WriteLine("Enter the " + k + " month salary");
                                        emp[i].salary[k] = int.Parse(Console.ReadLine());
                                        sum = sum + emp[i].salary[k];
                                    }

                                    emp[i].avgSalary = emp[i].avgSalary = sum / 3;
                                }
                                Console.WriteLine("----------------------------------");
                                break;
                            }

                        case inputs.Get_all_records:
                            {
                                for (int j = 0; j < max; j++)
                                {
                                    Console.WriteLine("id: " + emp[j].id);
                                    Console.WriteLine("the avg salary is : " + emp[j].avgSalary);
                                }
                                Console.WriteLine("----------------------------------");
                                break;
                            }

                        case inputs.Get_a_record:
                            {
                                Console.WriteLine("enter the index of the employee: ");
                                int g = int.Parse(Console.ReadLine());
                                Console.WriteLine("The employee id : " + emp[g].id);
                                Console.WriteLine("The avg salary of the employee : " + emp[g].avgSalary);
                                Console.WriteLine("----------------------------------");
                                break;
                            }

                        case inputs.Delete_a_record:
                            {
                                Console.WriteLine("Enter the index to delete a record : ");
                                int l = int.Parse(Console.ReadLine());
                                for (int j = l; j < max - 1; j++)
                                {
                                    emp[j].id = emp[j + 1].id;
                                    emp[j].salary = emp[j + 1].salary;
                                    emp[j].avgSalary = emp[j + 1].avgSalary;
                                }
                                max--;

                                Console.WriteLine("----------------------------------");
                                break;
                            }
                    }

                    Console.WriteLine("Type \"exit\" to exit the operations  or enter any key to continue: ");

                    s = Console.ReadLine();
                }
                Console.ReadLine();
            }

        }
    }
}
